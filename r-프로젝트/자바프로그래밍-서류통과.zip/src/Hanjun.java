
import javax.swing.*;
import javax.swing.JOptionPane;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Hanjun extends Start implements ActionListener
{
	public Hanjun() {
	}
 
	 int grade=0;
	
     JButton btn = new JButton("save!!!");
     JFrame f = new JFrame();
     
     public void go(){
 
       String answer = "";
       int question = 10;
       double response;
       String hakjum;
  
   	 	
   	 	JPanel panel = new JPanel();
   	 	JPanel panel2 = new JPanel();
   	 	JPanel panel3 = new JPanel();
       f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// 5 rows, 3 columns, no gaps
	   f.getContentPane().setLayout(new GridLayout(1, 1, 5, 5));
       
       
  
    	   switch (1)
    	   {
    	   	case 1:
    		   hakjum =  JOptionPane.showInputDialog(null,"������ �Է��ϼ���.(4.5���� �����Դϴ�)");
      	             response = Double.parseDouble(hakjum);
      	            		
      	             if (response >= 4.0)
			      	     {
		      	     		JOptionPane.showMessageDialog(null,"�ԷµǾ����ϴ�.");
		      	     		grade+=20;
			      	     }
		      	     else if(response >= 3.5)
		      	     	{
		      	    	 	JOptionPane.showMessageDialog(null,"�ԷµǾ����ϴ�.");
	      	     			grade+=18;
		      	     	}
		      	     else if(response >= 3.0)
	      	     		{
		      	    	 	JOptionPane.showMessageDialog(null,"�ԷµǾ����ϴ�.");
		      	    	 	grade+=16;
	      	     		}
		      	     else
		      	     	{
		      	    	 	JOptionPane.showMessageDialog(null,"�ԷµǾ����ϴ�.");
		      	    	 	grade+=10;
	      	     		}
		      	    	 
    	   	case 2:
     		   hakjum =  JOptionPane.showInputDialog(null,"���������� �Է��ϼ���.");
       	             response = Double.parseDouble(hakjum);
       	            		
       	             if (response >= 900)
 			      	     {
 		      	     		JOptionPane.showMessageDialog(null,"�ԷµǾ����ϴ�.");
 		      	     		grade+=20;
 			      	     }
       	             else if (response >= 800)
       	             	{
       	            	 	JOptionPane.showMessageDialog(null,"�ԷµǾ����ϴ�.");
       	            	 	grade+=18;
       	             	}
       	             else if (response >= 700)
       	             	{
       	            	 	JOptionPane.showMessageDialog(null,"�ԷµǾ����ϴ�.");
       	            	 	grade+=16;
       	             	}     
       	             else
       	             	{
    	            	 	JOptionPane.showMessageDialog(null,"�ԷµǾ����ϴ�.");
    	            	 	grade+=10;
    	             	}     
       	             
    	   	case 3:
      		   hakjum =  JOptionPane.showInputDialog(null,"���ϰ����� �Է��ϼ���.");
        	             response = Double.parseDouble(hakjum);
        	         if (response >= 3)
 			      	    {
 		      	     		JOptionPane.showMessageDialog(null,"�ԷµǾ����ϴ�.");
 		      	     		grade+=20;
 			      	    }
        	         else if (response == 2)
			      	    {
		      	     		JOptionPane.showMessageDialog(null,"�ԷµǾ����ϴ�.");
		      	     		grade+=18;
			      	    }
        	         else if (response == 1)
			      	    {
		      	     		JOptionPane.showMessageDialog(null,"�ԷµǾ����ϴ�.");
		      	     		grade+=16;
			      	    }
        	         else
			      	    {
		      	     		JOptionPane.showMessageDialog(null,"�ԷµǾ����ϴ�.");
		      	     		grade+=10;
			      	    }
    		case 4:
       		   hakjum =  JOptionPane.showInputDialog(null,"���Ȱ���� �Է��ϼ���.");
         	             response = Double.parseDouble(hakjum);
         	         if (response >= 3)
 			      	    {
 		      	     		JOptionPane.showMessageDialog(null,"�ԷµǾ����ϴ�.");
 		      	     		grade+=20;
 			      	    }
         	         else if (response == 2)
			      	    {
		      	     		JOptionPane.showMessageDialog(null,"�ԷµǾ����ϴ�.");
		      	     		grade+=18;
			      	    }
        	         else if (response == 1)
			      	    {
		      	     		JOptionPane.showMessageDialog(null,"�ԷµǾ����ϴ�.");
		      	     		grade+=16;
			      	    }
        	         else
			      	    {
		      	     		JOptionPane.showMessageDialog(null,"�ԷµǾ����ϴ�.");
		      	     		grade+=10;
			      	    }
		      	         
    		case 5:
        		   hakjum =  JOptionPane.showInputDialog(null,"�ڰ��� ������ �Է��ϼ���.");
          	             response = Double.parseDouble(hakjum);
          	         if (response >= 3)
  			      	    {
  		      	     		JOptionPane.showMessageDialog(null,"�ԷµǾ����ϴ�.");
  		      	     		grade+=20;
  			      	    }
          	         else if (response == 2)
 			      	    {
 		      	     		JOptionPane.showMessageDialog(null,"�ԷµǾ����ϴ�.");
 		      	     		grade+=18;
 			      	    }
         	         else if (response == 1)
 			      	    {
 		      	     		JOptionPane.showMessageDialog(null,"�ԷµǾ����ϴ�.");
 		      	     		grade+=16;
 			      	    }
         	         else
 			      	    {
 		      	     		JOptionPane.showMessageDialog(null,"�ԷµǾ����ϴ�.");
 		      	     		grade+=10;
 			      	    }
    	   		}
    	   String str = String.valueOf(grade);
    	   JLabel j1 = new JLabel("Total point : ");
    	   JLabel j2 = new JLabel(str);
    	   JLabel j3 = new JLabel("Uer ID : ");
   		   JLabel j4 = new JLabel(ID);
   		   btn.addActionListener(this);
   		   saveRank();
   		   
   		   panel3.add(j1);
   		   panel3.add(j2);
   		   panel.add(j3);
    	   panel.add(j4);
   		   panel2.add(new JLabel("���� ����"));
    	   panel2.add(btn);
    	   
    	   f.getContentPane().add(panel3);
    	   f.getContentPane().add(panel);
    	   f.getContentPane().add(panel2);
    	   
    	   
    	   f.setBounds(200, 200, 500, 100);
   		   f.setVisible(true);
       	
     }
     
 	public void saveRank() {

		char token = ',';
		JoinForm a = new JoinForm();
		String[][] indat = new String[100][5]; // indat�� csv �ϳ��ϳ��� �ִ´�.
		int row = 0, i;
		try {
			File path = new File("");
			File csv = new File(path.getCanonicalPath() + "//Join.csv");

			BufferedReader br = new BufferedReader(new FileReader(csv));
			String line = "";
			while ((line = br.readLine()) != null) {
				String[] token1 = line.split(",", -1);
				for (i = 0; i < 5; i++) {
					indat[row][i] = token1[i];
				}
				if (ID.equals(indat[row][0])) // ����ڰ� id�� ģ�Ͱ� csv�� ���̵� ĭ��
				{
					if(grade >= 77){
						indat[row][3] = String.valueOf(grade);
						indat[row][4] = "�հ�";
					}
					else
					{
						indat[row][3] = String.valueOf(grade);
						indat[row][4] = "���հ�";
					}
				}
				row++;
			}
			br.close();

			BufferedWriter bw = new BufferedWriter(new FileWriter("join.csv"));
			row--;
			for (i = 0; i <= row; i++) {
				bw.write(indat[i][0] + token + indat[i][1] + token + indat[i][2] + token + indat[i][3] + token	+ indat[i][4]);
				bw.write("\n");
			}
			bw.close();

		} catch (IOException e1) {
			e1.printStackTrace();
		}
		f.dispose();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource().equals(btn))
		{
			Rank r = new Rank();
			r.Rank();
			f.dispose();
		}
			
	}
}
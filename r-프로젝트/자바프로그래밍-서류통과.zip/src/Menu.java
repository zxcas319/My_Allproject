import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.border.TitledBorder;


public class Menu extends JFrame implements ActionListener{
	JFrame f = new JFrame("Select menu");
	public JButton [] btn = new JButton [4]; //6�� ����
	
	public Menu()
    {
		//GridLayout ����
		f.setLayout(new GridLayout(2,2));
		
		//�����̳� ��������
		Container container = f.getContentPane();
		
		//JButton buttonStart1 = new JButton(new ImageIcon("./images.png"));
	
		btn[0] = new JButton(new ImageIcon("./sam.png"));
		container.add(btn[0]);
		btn[1] = new JButton(new ImageIcon("./lg.png"));
		container.add(btn[1]);
		btn[2] = new JButton(new ImageIcon("./han.png"));
		container.add(btn[2]);
		btn[3] = new JButton(new ImageIcon("./shin.png"));
		container.add(btn[3]);
		
		btn[0].addActionListener(this);
		btn[1].addActionListener(this);
		btn[2].addActionListener(this);
		btn[3].addActionListener(this);
		
		
		
		//������ ũ�� �����ϱ�
		f.setSize(1000,700);
		
		//������ ���̱�
		f.setVisible(true);
		
		//�����ư�� ���� ����
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	 
    }

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource().equals(btn[0])) {
			f.dispose();
			 Samsung s = new Samsung();
			 s.go();
		}

		if (e.getSource().equals(btn[1])) // study�� ��
		{
			f.dispose();
			LG l = new LG();
			l.go();
		}

		if (e.getSource().equals(btn[2])) // study�� ��
		{
			f.dispose();
			Hanjun h = new Hanjun();
			h.go();
		}
		
		if(e.getSource().equals(btn[3]))
		{
			f.dispose();
			Shinhan sh = new Shinhan();
			sh.go();
		}
	}
	

}
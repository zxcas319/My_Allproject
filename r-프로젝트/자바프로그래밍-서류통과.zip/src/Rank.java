
import java.awt.Container;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.border.TitledBorder;

public class Rank extends JFrame implements ActionListener {

	public JLabel name;
	public JButton menu;
	public String board ="";
	public JTextArea rank;
	
	JFrame f = new JFrame();
	
	public void Rank(){
	
	Container panel = f.getContentPane();
	panel.setLayout(new GridBagLayout());
	f.setTitle("Rank!!!");
	f.setSize(600, 300);
	
	TitledBorder border = BorderFactory.createTitledBorder("Record!");
	((JComponent) panel).setBorder(border);
	receiveRank();

	panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
	rank = new JTextArea(100, 200);
	rank.setText(board);
	rank.setEnabled(false);
	panel.add(rank);
	menu = new JButton("menu");
	panel.add(menu);

	menu.addActionListener(this);

	f.setVisible(true);
	f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

}

public void receiveRank() {

	char token = ',';
	JoinForm a = new JoinForm();

	String[][] indat = new String[100][5]; // indat�� csv �ϳ��ϳ��� �ִ´�.
	int row = 0, i;
	try {
		File path = new File("");
		File csv = new File(path.getCanonicalPath() + "//Join.csv");
		System.out.println("yes");
		BufferedReader br = new BufferedReader(new FileReader(csv));
		String line = "";
		String[] ID = new String[100];
		int[] rank = new int[100];
		String[] success = new String[100];
		while ((line = br.readLine()) != null) {
			String[] token1 = line.split(",", -1);
			System.out.println(token1);
			ID[row] = token1[0];
			success[row] = token1[4];
			int k = Integer.parseInt(token1[3]);
			rank[row] = k;
			row++;
		}
		br.close();
		row--;
//		int temp = 0;W
		String s = null;
		System.out.println("yes3");
/*
		for (int j = 1; j <= row; j++) {
			for (int z = 0; z <= row; z++) {
				if (rank[z] < rank[z + 1]) {
					temp = rank[z];
					rank[z] = rank[z + 1];
					rank[z + 1] = temp;
					s = ID[z];
					ID[z] = ID[z + 1];
					ID[z + 1] = s;
				}
			}

		}*/
		int count = 0;
		board += "ID:\tScore:\t�������:\n";
		while (count <= row) {
			System.out.println("yes4");
			System.out.print(success[count]);
			board += (ID[count] + "\t" + String.valueOf(rank[count]) + "\t" + success[count] + "\t");
			board += "\n";
			count++;
		}
	} catch (Exception e) {
		e.getMessage();
	}
}

@Override
public void actionPerformed(ActionEvent e) {

	if (e.getSource().equals(menu)) {
		f.dispose();
		Menu a = new Menu();
	}
}

}

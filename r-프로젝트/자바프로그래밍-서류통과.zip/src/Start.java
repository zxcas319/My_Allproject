import java.awt.Color;
import java.awt.Container;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

public class Start extends JFrame implements ActionListener{

	public JLabel Username;
	public JLabel Password;
	public JTextField writeUsername;
	public JTextField writePassword;
	public JButton login;
	public JButton joinid;
	public static String ID;
	JFrame frame = new JFrame("Welcome to EarthPrograme");
	
	
	public void main(){
		Container panel = frame.getContentPane();
		panel.setLayout(null);

		Username = new JLabel("User");
		Username.setBounds(10, 10, 80, 25);
		panel.add(Username);

		writeUsername = new JTextField(20);
		writeUsername.setBounds(100, 10, 160, 25);
		panel.add(writeUsername);

		Password = new JLabel("Password");
		Password.setBounds(10, 40, 80, 25);
		panel.add(Password);

		writePassword = new JPasswordField(20);
		writePassword.setBounds(100, 40, 160, 25);
		panel.add(writePassword);

		login = new JButton("login");
		login.setBounds(10, 80, 80, 25);
		panel.add(login);
		
		joinid = new JButton("register");
		joinid.setBounds(180, 80, 80, 25);
		panel.add(joinid);
		
		login.addActionListener(this);
		joinid.addActionListener(this);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		frame.setSize(300, 150);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);

	}

	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}

	public void actionPerformed(ActionEvent e) {

		String[][] indata = new String[100][5]; // indat�� csv �ϳ��ϳ��� �ִ´�.
		int row = 0, i;
				
		if (e.getSource().equals(joinid)) // ȸ�������� ��������
		{
			JoinForm j = new JoinForm();
			j.JoinForm();
		}

		else if (e.getSource().equals(login)) // Ȯ�� ��ư�� ��������
		{
			setID(writeUsername.getText());
			try {
				File path = new File("");
			    File csv = new File(path.getCanonicalPath()+"//Join.csv");
			
			    BufferedReader BR = new BufferedReader(new FileReader(csv));
				
				String line = "";
				while ((line = BR.readLine()) != null) {
					String[] token = line.split(",");
					for (i = 0; i < 5; i++) {
						indata[row][i] = token[i];
					}
					row++;
				}
				BR.close();
			}
			 catch (FileNotFoundException e1) {
				e1.printStackTrace();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			for ( i = 0; i < 100; i++) {
				if (writeUsername.getText().equals(indata[i][0])) // ����ڰ� id�� ģ�Ͱ� csv�� ���̵� ĭ�� ��������������
				{
					if (writePassword.getText().equals(indata[i][1])) // ������� id�� ����  password�� csv�� ���Ҷ�
					{
						Menu a1 = new Menu(); 
						frame.dispose();
					}

				}

			}
			if (frame.isShowing() == true) // ���� �� class �� frame�� ����ִٸ�!!
			{
				IdPasswordCheck a = new IdPasswordCheck();
				frame.dispose();
			} // Ʋ���� IdPasswordCheck Ŭ�����ΰ��� �ٽ� Idmake JFrame���� �Ű�����

		}
		
	}
	
	public static void main(String[] args) {
		Start s = new Start(); 
		s.main();
	}
	
}



import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class idcheck implements ActionListener {
	JFrame f = new JFrame("JoinForm!!");

	public idcheck(){
		JPanel p = new JPanel();
		JLabel change = new JLabel("ID is can not use, please change     ");
		JButton ok = new JButton("OK");
		ok.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {
					f.dispose();
			}
		});
		p.setLayout(new GridBagLayout());
		p.add(change);
		p.add(ok).setLocation(150, 75);
		
		f.getContentPane().add(p);
		f.setBounds(600, 300, 300, 150);
		f.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

	}
}
